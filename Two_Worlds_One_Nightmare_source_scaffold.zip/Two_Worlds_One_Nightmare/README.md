# Two Worlds, One Nightmare

**Tagline:** Follow a trail of clues between Dying Light and Silver Pines.

## Current status

**Source scaffold only — not a playable mod and not ready to publish.** This package contains the initial design sheets and a read-only file inventory helper. It does not yet alter Dying Light gameplay, load Silver Pines content in-game, or contain a Melty-validated recipe.

## Intended design

- **Primary host:** Dying Light (`dying-light`).
- **Required companion:** Silver Pines (`custom-silver-pines`).
- **Mode:** single player.
- **First playable scope:** one short investigation linking three clues between the two games.
- Both games' own content must be read from each player's installed copy. Do not copy game assets into this project or its release.

## Files

- `sheets/project.json` — scope and game roles.
- `sheets/clues.json` — clue sheet; source paths intentionally blank until inspected against real installed copies.
- `sheets/systems.json` — integration systems and their status.
- `src/inventory_game_files.py` — read-only helper that indexes relative paths in both game folders.
- `tests/test_inventory.py` — test for the path inventory helper.

## Run the helper

Requires Python 3.10+; this is a developer helper, not a runtime dependency for players.

```bash
python -m unittest tests.test_inventory
python src/inventory_game_files.py --dying-light "/path/to/Dying Light" --silver-pines "/path/to/Silver Pines" --out asset-index.json
```

The inventory may include filenames that are not useful or readable. Every candidate clue must be reviewed against the installed game, and a real Dying Light mod hook must be confirmed before gameplay code is written.

## Blocking items before a playable build

1. Inspect both installed game folders and identify their actual engine/content formats and relevant assets.
2. Confirm a viable, publishable Dying Light hook/loader and how it can present a clue in-game.
3. Implement the hook and clue progression against the actual game, then test in-game.
4. Connect to Melty, validate the recipe and package, run Melty's one-click test, and capture real gameplay media.
5. Set the license and remix permissions before publication.

## Credits and permissions

Not yet set. No third-party assets are included. The license and remix policy must be chosen by the project owner before publishing.
