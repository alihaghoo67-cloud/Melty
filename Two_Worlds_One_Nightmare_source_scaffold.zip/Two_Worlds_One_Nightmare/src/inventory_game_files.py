#!/usr/bin/env python3
"""Read-only inventory of candidate clue files in game folders.

This tool never copies, extracts, modifies, or redistributes game assets.
It records relative paths only. It is an inspection helper, not an in-game mod.
"""
import argparse
import json
from pathlib import Path

INTERESTING_EXTENSIONS = {
    ".txt", ".json", ".xml", ".lua", ".script", ".ogg", ".wav", ".wem",
    ".png", ".dds", ".tga", ".jpg", ".jpeg", ".wem", ".bnk", ".bundle"
}

def inventory(root: Path, game_slug: str):
    if not root.exists() or not root.is_dir():
        raise ValueError(f"Game folder does not exist or is not a directory: {root}")
    rows = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in INTERESTING_EXTENSIONS:
            continue
        try:
            relative = path.relative_to(root).as_posix()
        except ValueError:
            continue
        rows.append({"game": game_slug, "relative_path": relative, "extension": path.suffix.lower()})
    return sorted(rows, key=lambda row: row["relative_path"].lower())

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dying-light", type=Path, required=True, help="Path to the player's Dying Light installation")
    parser.add_argument("--silver-pines", type=Path, required=True, help="Path to the player's Silver Pines installation")
    parser.add_argument("--out", type=Path, default=Path("asset-index.json"), help="Output JSON path")
    args = parser.parse_args()
    result = {
        "warning": "Candidate file index only; filenames do not prove story relevance or format compatibility.",
        "copies_game_assets": False,
        "games": inventory(args.dying_light, "dying-light") + inventory(args.silver_pines, "custom-silver-pines")
    }
    args.out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Wrote {len(result['games'])} path references to {args.out}; no game assets were copied.")

if __name__ == "__main__":
    main()
