import tempfile
import unittest
from pathlib import Path
from src.inventory_game_files import inventory

class InventoryTests(unittest.TestCase):
    def test_indexes_paths_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "data").mkdir()
            (root / "data" / "note.txt").write_text("dummy")
            (root / "data" / "ignored.exe").write_text("dummy")
            rows = inventory(root, "example")
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["relative_path"], "data/note.txt")
            self.assertEqual(rows[0]["game"], "example")

if __name__ == "__main__":
    unittest.main()
